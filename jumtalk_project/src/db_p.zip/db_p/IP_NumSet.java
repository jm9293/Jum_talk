package db_p;

public class IP_NumSet {
	static final String host = "192.168.0.218";
}
